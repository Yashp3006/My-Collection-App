using System;
using System.Data.SqlTypes;
using System.Reflection.Metadata;
using System.Windows.Forms;
using CollectionApp;

namespace My_Collection_App
{
    /// <summary>
    /// Main form that displays the collection overview and allows navigation to other features.
    /// </summary>
    public partial class MyCollectionApp : Form
    {
        /// <summary>
        /// Initializes the main form components.
        /// </summary>
        public MyCollectionApp()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Opens the Add Item form to add a new item to the collection.
        /// </summary>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            CollectionApplicationItems addForm = new CollectionApplicationItems();
            addForm.ShowDialog(); // Opens Add/Edit form as a modal popup
        }

        /// <summary>
        /// Opens the Edit Item form to modify the selected item in the collection.
        /// </summary>
        private void btnEdit_Click(object sender, EventArgs e)
        {
            CollectionApplicationItems editForm = new CollectionApplicationItems();
            editForm.ShowDialog(); // Opens Add/Edit form as a modal popup
        }

        /// <summary>
        /// Displays a message for Delete (functionality to be implemented later).
        /// </summary>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Delete function can be added later.");
        }

        /// <summary>
        /// Closes the application.
        /// </summary>
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSaveCollection_Click(object sender, EventArgs e)
        {

            MessageBox.Show("Collection saved successfully.");
        }

        private void btnOpenCollection_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Open Collection clicked.");
        }


        /// <summary>
        /// Handler for opening a collection file (not yet implemented).
        /// </summary>
        private void openCollectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Open Collection clicked.");
        }

        /// <summary>
        /// Handler for saving a collection file (not yet implemented).
        /// </summary>
        private void saveCollectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Save Collection clicked.");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lstItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstItems.SelectedItem != null)
            {
                CollectionItem selectedItem = (CollectionItem)lstItems.SelectedItem;
                MessageBox.Show(
                    $"Title: {selectedItem.Title}\nDescription: {selectedItem.Description}",
                    "Item Details",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOpenCollection_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            openFileDialog.Title = "Open Collection File";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                try
                {
                    string[] lines = File.ReadAllLines(filePath);

                    lstItems.Items.Clear(); // Clear current list

                    foreach (string line in lines)
                    {
                        // Split format: Title|Description|Favorite
                        string[] parts = line.Split('|');
                        if (parts.Length >= 2)
                        {
                            string title = parts[0];
                            string description = parts[1];
                            bool isFavorite = parts.Length > 2 && bool.Parse(parts[2]);
                        }
                    }

                    MessageBox.Show("Collection loaded successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error reading file: {ex.Message}");
                }
            }
        }
    }
}