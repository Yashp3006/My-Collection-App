﻿namespace My_Collection_App
{
    partial class MyCollectionApp
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MyCollectionApp));
            lstItems = new ListBox();
            btnAdd = new Button();
            btnEdit = new Button();
            btnDelete = new Button();
            btnExit = new Button();
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            editToolStripMenuItem = new ToolStripMenuItem();
            viewToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem = new ToolStripMenuItem();
            openCollectionToolStripMenuItem = new ToolStripMenuItem();
            saveCollectionToolStripMenuItem = new ToolStripMenuItem();
            toolStrip1 = new ToolStrip();
            toolStripButtonOpen = new ToolStripButton();
            toolStripButtonSave = new ToolStripButton();
            toolStripButtonExi = new ToolStripButton();
            ToolStripStatusLabel = new StatusStrip();
            pictureBox1 = new PictureBox();
            btnSaveCollection = new Button();
            btnOpenCollection = new Button();
            menuStrip1.SuspendLayout();
            toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lstItems
            // 
            lstItems.FormattingEnabled = true;
            lstItems.ItemHeight = 15;
            lstItems.Location = new Point(12, 51);
            lstItems.Margin = new Padding(3, 2, 3, 2);
            lstItems.Name = "lstItems";
            lstItems.Size = new Size(241, 214);
            lstItems.TabIndex = 2;
            lstItems.SelectedIndexChanged += lstItems_SelectedIndexChanged;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(281, 44);
            btnAdd.Margin = new Padding(3, 2, 3, 2);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(82, 22);
            btnAdd.TabIndex = 3;
            btnAdd.Text = "&Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(281, 91);
            btnEdit.Margin = new Padding(3, 2, 3, 2);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(82, 22);
            btnEdit.TabIndex = 4;
            btnEdit.Text = "&Edit";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(281, 144);
            btnDelete.Margin = new Padding(3, 2, 3, 2);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(82, 21);
            btnDelete.TabIndex = 5;
            btnDelete.Text = "&Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(281, 232);
            btnExit.Margin = new Padding(3, 2, 3, 2);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(82, 22);
            btnExit.TabIndex = 6;
            btnExit.Text = "&Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, editToolStripMenuItem, viewToolStripMenuItem, helpToolStripMenuItem, openCollectionToolStripMenuItem, saveCollectionToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(5, 2, 0, 2);
            menuStrip1.Size = new Size(644, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "File";
            // 
            // editToolStripMenuItem
            // 
            editToolStripMenuItem.Name = "editToolStripMenuItem";
            editToolStripMenuItem.Size = new Size(39, 20);
            editToolStripMenuItem.Text = "Edit";
            // 
            // viewToolStripMenuItem
            // 
            viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            viewToolStripMenuItem.Size = new Size(44, 20);
            viewToolStripMenuItem.Text = "View";
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(44, 20);
            helpToolStripMenuItem.Text = "Help";
            // 
            // openCollectionToolStripMenuItem
            // 
            openCollectionToolStripMenuItem.Name = "openCollectionToolStripMenuItem";
            openCollectionToolStripMenuItem.Size = new Size(105, 20);
            openCollectionToolStripMenuItem.Text = "Open Collection";
            openCollectionToolStripMenuItem.Click += openCollectionToolStripMenuItem_Click;
            // 
            // saveCollectionToolStripMenuItem
            // 
            saveCollectionToolStripMenuItem.Name = "saveCollectionToolStripMenuItem";
            saveCollectionToolStripMenuItem.Size = new Size(100, 20);
            saveCollectionToolStripMenuItem.Text = "Save Collection";
            saveCollectionToolStripMenuItem.Click += saveCollectionToolStripMenuItem_Click;
            // 
            // toolStrip1
            // 
            toolStrip1.ImageScalingSize = new Size(20, 20);
            toolStrip1.Items.AddRange(new ToolStripItem[] { toolStripButtonOpen, toolStripButtonSave, toolStripButtonExi });
            toolStrip1.Location = new Point(0, 24);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new Size(644, 25);
            toolStrip1.TabIndex = 1;
            toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButtonOpen
            // 
            toolStripButtonOpen.DisplayStyle = ToolStripItemDisplayStyle.Text;
            toolStripButtonOpen.Image = (Image)resources.GetObject("toolStripButtonOpen.Image");
            toolStripButtonOpen.ImageTransparentColor = Color.Magenta;
            toolStripButtonOpen.Name = "toolStripButtonOpen";
            toolStripButtonOpen.Size = new Size(40, 22);
            toolStripButtonOpen.Text = "&Open";
            // 
            // toolStripButtonSave
            // 
            toolStripButtonSave.DisplayStyle = ToolStripItemDisplayStyle.Text;
            toolStripButtonSave.Image = (Image)resources.GetObject("toolStripButtonSave.Image");
            toolStripButtonSave.ImageTransparentColor = Color.Magenta;
            toolStripButtonSave.Name = "toolStripButtonSave";
            toolStripButtonSave.Size = new Size(35, 22);
            toolStripButtonSave.Text = "&Save";
            // 
            // toolStripButtonExi
            // 
            toolStripButtonExi.DisplayStyle = ToolStripItemDisplayStyle.Text;
            toolStripButtonExi.Image = (Image)resources.GetObject("toolStripButtonExi.Image");
            toolStripButtonExi.ImageTransparentColor = Color.Magenta;
            toolStripButtonExi.Name = "toolStripButtonExi";
            toolStripButtonExi.Size = new Size(30, 22);
            toolStripButtonExi.Text = "&Exit";
            // 
            // ToolStripStatusLabel
            // 
            ToolStripStatusLabel.ImageScalingSize = new Size(20, 20);
            ToolStripStatusLabel.Location = new Point(0, 337);
            ToolStripStatusLabel.Name = "ToolStripStatusLabel";
            ToolStripStatusLabel.Padding = new Padding(1, 0, 12, 0);
            ToolStripStatusLabel.Size = new Size(644, 22);
            ToolStripStatusLabel.TabIndex = 9;
            ToolStripStatusLabel.Text = "Ready.";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(386, 44);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(241, 211);
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // btnSaveCollection
            // 
            btnSaveCollection.Location = new Point(254, 283);
            btnSaveCollection.Margin = new Padding(3, 2, 3, 2);
            btnSaveCollection.Name = "btnSaveCollection";
            btnSaveCollection.Size = new Size(123, 22);
            btnSaveCollection.TabIndex = 8;
            btnSaveCollection.Text = "Sav&e Collection";
            btnSaveCollection.UseVisualStyleBackColor = true;
            // 
            // btnOpenCollection
            // 
            btnOpenCollection.Location = new Point(12, 283);
            btnOpenCollection.Margin = new Padding(3, 2, 3, 2);
            btnOpenCollection.Name = "btnOpenCollection";
            btnOpenCollection.Size = new Size(127, 22);
            btnOpenCollection.TabIndex = 7;
            btnOpenCollection.Text = "O&pen Collection";
            btnOpenCollection.UseVisualStyleBackColor = true;
            btnOpenCollection.Click += btnOpenCollection_Click_1;
            // 
            // MyCollectionApp
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(644, 359);
            Controls.Add(btnOpenCollection);
            Controls.Add(btnSaveCollection);
            Controls.Add(pictureBox1);
            Controls.Add(ToolStripStatusLabel);
            Controls.Add(toolStrip1);
            Controls.Add(btnExit);
            Controls.Add(btnDelete);
            Controls.Add(btnEdit);
            Controls.Add(btnAdd);
            Controls.Add(lstItems);
            Controls.Add(menuStrip1);
            Margin = new Padding(3, 2, 3, 2);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "MyCollectionApp";
            Text = "My Collection App";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox lstItems;
        private Button btnAdd;
        private Button btnEdit;
        private Button btnDelete;
        private Button btnExit;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem editToolStripMenuItem;
        private ToolStripMenuItem viewToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem openCollectionToolStripMenuItem;
        private ToolStripMenuItem saveCollectionToolStripMenuItem;
        private ToolStrip toolStrip1;
        private ToolStripButton toolStripButtonOpen;
        private ToolStripButton toolStripButtonSave;
        private ToolStripButton toolStripButtonExi;
        private StatusStrip ToolStripStatusLabel;
        private PictureBox pictureBox1;
        private Button btnSaveCollection;
        private Button btnOpenCollection;
    }
}
