﻿namespace My_Collection_App
{
    partial class CollectionApplicationItems
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtDescription = new TextBox();
            dateTimePicker1 = new DateTimePicker();
            txtName = new TextBox();
            btnName = new Button();
            textBox4 = new TextBox();
            btnDescription = new Button();
            btnDateAcquired = new Button();
            button4 = new Button();
            btnSave = new Button();
            btnCancel = new Button();
            grbBox = new GroupBox();
            rdoUsed = new RadioButton();
            New = new RadioButton();
            chkFavorite = new CheckBox();
            grbBox.SuspendLayout();
            SuspendLayout();
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(125, 73);
            txtDescription.Margin = new Padding(3, 2, 3, 2);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(219, 23);
            txtDescription.TabIndex = 3;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(125, 135);
            dateTimePicker1.Margin = new Padding(3, 2, 3, 2);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(219, 23);
            dateTimePicker1.TabIndex = 5;
            // 
            // txtName
            // 
            txtName.Location = new Point(125, 10);
            txtName.Margin = new Padding(3, 2, 3, 2);
            txtName.Name = "txtName";
            txtName.Size = new Size(219, 23);
            txtName.TabIndex = 1;
            // 
            // btnName
            // 
            btnName.Location = new Point(10, 9);
            btnName.Margin = new Padding(3, 2, 3, 2);
            btnName.Name = "btnName";
            btnName.Size = new Size(109, 22);
            btnName.TabIndex = 0;
            btnName.Text = "N&ame";
            btnName.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(125, 201);
            textBox4.Margin = new Padding(3, 2, 3, 2);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(219, 23);
            textBox4.TabIndex = 7;
            // 
            // btnDescription
            // 
            btnDescription.Location = new Point(10, 71);
            btnDescription.Margin = new Padding(3, 2, 3, 2);
            btnDescription.Name = "btnDescription";
            btnDescription.Size = new Size(109, 22);
            btnDescription.TabIndex = 2;
            btnDescription.Text = "Des&cription";
            btnDescription.UseVisualStyleBackColor = true;
            // 
            // btnDateAcquired
            // 
            btnDateAcquired.Location = new Point(10, 134);
            btnDateAcquired.Margin = new Padding(3, 2, 3, 2);
            btnDateAcquired.Name = "btnDateAcquired";
            btnDateAcquired.Size = new Size(109, 22);
            btnDateAcquired.TabIndex = 4;
            btnDateAcquired.Text = "&Date Acquired";
            btnDateAcquired.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(10, 200);
            button4.Margin = new Padding(3, 2, 3, 2);
            button4.Name = "button4";
            button4.Size = new Size(109, 22);
            button4.TabIndex = 6;
            button4.Text = "&Custom Field";
            button4.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(279, 297);
            btnSave.Margin = new Padding(3, 2, 3, 2);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(82, 22);
            btnSave.TabIndex = 10;
            btnSave.Text = "&Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(403, 297);
            btnCancel.Margin = new Padding(3, 2, 3, 2);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(82, 22);
            btnCancel.TabIndex = 11;
            btnCancel.Text = "&Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click_1;
            // 
            // grbBox
            // 
            grbBox.Controls.Add(rdoUsed);
            grbBox.Controls.Add(New);
            grbBox.Location = new Point(10, 235);
            grbBox.Margin = new Padding(3, 2, 3, 2);
            grbBox.Name = "grbBox";
            grbBox.Padding = new Padding(3, 2, 3, 2);
            grbBox.Size = new Size(219, 45);
            grbBox.TabIndex = 8;
            grbBox.TabStop = false;
            // 
            // rdoUsed
            // 
            rdoUsed.AutoSize = true;
            rdoUsed.Location = new Point(143, 24);
            rdoUsed.Margin = new Padding(3, 2, 3, 2);
            rdoUsed.Name = "rdoUsed";
            rdoUsed.Size = new Size(51, 19);
            rdoUsed.TabIndex = 1;
            rdoUsed.TabStop = true;
            rdoUsed.Text = "Use&d";
            rdoUsed.UseVisualStyleBackColor = true;
            // 
            // New
            // 
            New.AutoSize = true;
            New.Location = new Point(10, 24);
            New.Margin = new Padding(3, 2, 3, 2);
            New.Name = "New";
            New.Size = new Size(49, 19);
            New.TabIndex = 0;
            New.TabStop = true;
            New.Text = "&New";
            New.UseVisualStyleBackColor = true;
            // 
            // chkFavorite
            // 
            chkFavorite.AutoSize = true;
            chkFavorite.Location = new Point(10, 297);
            chkFavorite.Margin = new Padding(3, 2, 3, 2);
            chkFavorite.Name = "chkFavorite";
            chkFavorite.Size = new Size(112, 19);
            chkFavorite.TabIndex = 9;
            chkFavorite.Text = "&Mark as Favorite";
            chkFavorite.UseVisualStyleBackColor = true;
            chkFavorite.CheckedChanged += chkFavorite_CheckedChanged;
            // 
            // CollectionApplicationItems
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(700, 338);
            Controls.Add(chkFavorite);
            Controls.Add(grbBox);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(button4);
            Controls.Add(btnDateAcquired);
            Controls.Add(btnDescription);
            Controls.Add(textBox4);
            Controls.Add(btnName);
            Controls.Add(txtName);
            Controls.Add(dateTimePicker1);
            Controls.Add(txtDescription);
            Margin = new Padding(3, 2, 3, 2);
            Name = "CollectionApplicationItems";
            Text = "Collection Application Items";
            grbBox.ResumeLayout(false);
            grbBox.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtDescription;
        private DateTimePicker dateTimePicker1;
        private ComboBox comboBox1;
        private TextBox txtName;
        private Button btnName;
        private TextBox textBox4;
        private Button btnDescription;
        private Button btnDateAcquired;
        private Button button4;
        private Button btnSave;
        private Button btnCancel;
        private GroupBox grbBox;
        private RadioButton New;
        private RadioButton rdoUsed;
        private CheckBox chkFavorite;
    }
}