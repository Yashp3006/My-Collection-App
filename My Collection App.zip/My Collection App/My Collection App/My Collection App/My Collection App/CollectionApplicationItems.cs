﻿using System;
using System.Windows.Forms;



namespace My_Collection_App
{
    /// <summary>
    /// Form used to add or edit an item in the collection.
    /// </summary>
    public partial class CollectionApplicationItems : Form
    {
        /// <summary>
        /// Initializes the Add/Edit Item form.
        /// </summary>
        public CollectionApplicationItems()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the Save button click event.
        /// Displays confirmation and closes the form.
        /// </summary>
        private void btnSave_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Item Saved (You can add logic here later).");
            this.Close(); // Close the form after saving
        }

        /// <summary>
        /// Handles the Cancel button click event.
        /// Closes the form without saving.
        /// </summary>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close(); // Just close the form
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chkFavorite_CheckedChanged(object sender, EventArgs e)
        {
            if (chkFavorite.Checked)
            {
                chkFavorite.Text = "This item is marked as favorite.";
            }
            else
            {
                chkFavorite.Text = "";
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
