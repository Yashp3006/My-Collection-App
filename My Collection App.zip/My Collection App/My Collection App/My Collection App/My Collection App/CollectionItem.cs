﻿using System;
using System.Globalization;

namespace CollectionApp
{
    /// <summary>
    /// Represents an item in a collection with a name, date acquired, and description.
    /// This is an abstract class and cannot be instantiated directly.
    /// </summary>
    public abstract class CollectionItem
    {
        // Common properties for all collection items
        public string Name { get; set; } // Auto-implemented property
        private string dateAcquired;
        private string title;

        public string Description { get; set; } // Auto-implemented property

        /// <summary>
        /// Initializes a new instance of the <see cref="CollectionItem"/> class with the specified name, date acquired, and description.
        /// </summary>
        /// <param name="name">The name of the collection item.</param>
        /// <param name="dateAcquired">The date the item was acquired, in MM/DD/YYYY format, or null.</param>
        /// <param name="description">A description of the collection item.</param>
        protected CollectionItem(string name, string dateAcquired, string description)
        {
            Name = name;
            DateAcquired = dateAcquired; // Allows null or valid date format
            Description = description;
        }

        protected CollectionItem(string title, string description)
        {
            this.title = title;
            Description = description;
        }

        /// <summary>
        /// Gets or sets the date the item was acquired, in MM/DD/YYYY format, or null.
        /// </summary>
        public string DateAcquired
        {
            get => dateAcquired;
            set
            {
                if (string.IsNullOrEmpty(value) || IsValidDate(value))
                {
                    dateAcquired = value; // Accepts null or valid date format
                }
                else
                {
                    throw new ArgumentException("Date must be in MM/DD/YYYY format or empty.");
                }
            }
        }

        public object Title { get; internal set; }

        /// <summary>
        /// Validates if the provided date is in MM/DD/YYYY format.
        /// </summary>
        /// <param name="date">The date string to validate.</param>
        /// <returns>True if the date is in MM/DD/YYYY format; otherwise, false.</returns>
        private bool IsValidDate(string date)
        {
            return DateTime.TryParseExact(date, "M/d/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out _);
        }

        /// <summary>
        /// Displays a summary of the collection item.
        /// </summary>
        /// <returns>A string containing the summary of the collection item.</returns>
        public virtual string GetSummary()
        {
            string dateInfo = string.IsNullOrEmpty(DateAcquired) ? "Unknown" : DateAcquired;
            return $"{Name} - Acquired on {dateInfo}";
        }
        /// <summary>
        /// 
        /// </summary>
        public class MyCollectionItem : CollectionItem
        {
            /// <summary>
            /// 
            /// </summary>
            public bool IsFavorite { get; set; }
            /// <summary>
            /// 
            /// </summary>
            /// <param name="title"></param>
            /// <param name="description"></param>
            /// <param name="isFavorite"></param>
            public MyCollectionItem(string title, string description, bool isFavorite)
                 : base(title, description)
            {
                this.IsFavorite = isFavorite;
            }
            /// <summary>
            /// 
            /// </summary>
            public class CollectionItem
            {
                /// <summary>
                /// 
                /// </summary>
                /// <param name="title"></param>
                /// <param name="description"></param>
                public CollectionItem(string title, string description)
                {
                    Title = title;
                    Description = description;
                }
                /// <summary>
                /// 
                /// </summary>
                public string Title { get; set; }
                public string Description { get; set; }
                /// <summary>
                /// 
                /// </summary>
                /// <returns></returns>
                public override string ToString()
                {
                    return Title;
                }
            }
            /// <summary>
            /// 
            /// </summary>
            /// <returns></returns>
            public override string ToString()
            {
                return (string)Title;
            }
            /// <summary>
            /// 
            /// </summary>
            public class MyCollectionApp : CollectionItem
            {
                /// <summary>
                /// 
                /// </summary>
                public bool IsFavorite { get; set; }
                /// <summary>
                /// 
                /// </summary>
                /// <param name="title"></param>
                /// <param name="description"></param>
                /// <param name="isFavorite"></param>
                public MyCollectionApp(string title, string description, bool isFavorite)
                    : base(title, description)
                {
                    IsFavorite = isFavorite;
                }
                /// <summary>
                /// 
                /// </summary>
                /// <returns></returns>
                public override string ToString()
                {
                    return Title + (IsFavorite ? " [★]" : "");
                }
            }
        }



    }
}