﻿using System;
using System.Collections.Generic;
using System.IO;
using My_Collection_App; // Namespace for VideoGame
using CollectionApp;

namespace My_Collection_App
{
    public static class CollectionDB
    {
        private const string FilePath = "collection.txt";

        /// <summary>
        /// Saves all collection items to a text file.
        /// </summary>
        public static void SaveItems(List<CollectionItem> items)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(FilePath))
                {
                    foreach (var item in items)
                    {
                        if (item is VideoGame game)
                        {
                            // Format: Type|Name|Date|Description|Platform
                            writer.WriteLine($"VideoGame|{game.Name}|{game.DateAcquired}|{game.Description}|{game.Platform}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving file: " + ex.Message);
            }
        }

        /// <summary>
        /// Loads collection items from a text file.
        /// </summary>
        public static List<CollectionItem> LoadItems()
        {
            List<CollectionItem> items = new List<CollectionItem>();

            try
            {
                if (File.Exists(FilePath))
                {
                    using (StreamReader reader = new StreamReader(FilePath))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            string[] parts = line.Split('|');
                            if (parts[0] == "VideoGame" && parts.Length == 5)
                            {
                                string name = parts[1];
                                string date = parts[2];
                                string desc = parts[3];
                                string platform = parts[4];

                                items.Add(new VideoGame(name, date, desc, platform));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading file: " + ex.Message);
            }

            return items;
        }
    }
}
