﻿using System;
using CollectionApp;
using System.Xml.Linq;

namespace My_Collection_App
{
    /// <summary>
    /// Represents a video game item in the user's collection.
    /// </summary>
    public class VideoGame : CollectionItem
    {
        /// <summary>
        /// The gaming platform for the video game (e.g., PC, Xbox, PlayStation).
        /// </summary>
        public string Platform { get; set; }

        /// <summary>
        /// Initializes a new instance of the VideoGame class with name, date, description, and platform.
        /// </summary>
        /// <param name="name">The name/title of the video game.</param>
        /// <param name="dateAcquired">The date the video game was acquired (MM/DD/YYYY).</param>
        /// <param name="description">A short description of the game.</param>
        /// <param name="platform">The platform on which the game is played.</param>
        public VideoGame(string name, string dateAcquired, string description, string platform)
            : base(name, dateAcquired, description)
        {
            Platform = platform;
        }

        /// <summary>
        /// Returns a formatted string summarizing the video game details.
        /// </summary>
        /// <returns>A summary string including name, platform, and acquisition date.</returns>
        public override string GetSummary()
        {
            string dateInfo = string.IsNullOrEmpty(DateAcquired) ? "Unknown" : DateAcquired;
            return $"{Name} ({Platform}) - Acquired on {dateInfo}";
        }
    }
}
